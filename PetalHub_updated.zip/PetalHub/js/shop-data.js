window.PetalHubData = {
  wrappingDesigns: [
    { id: "pink-elegance", name: "Pink Elegance", color: "Blush pink", price: 75, detail: "Premium pink matte wrapping paper with satin ribbon.", image: "https://i.pinimg.com/1200x/10/3a/b7/103ab76c85c18521d5ba2addbd7689af.jpg" },
    { id: "classic-kraft", name: "Classic Kraft", color: "Natural brown", price: 50, detail: "Eco-friendly brown kraft paper with natural jute twine.", image: "https://i.pinimg.com/originals/a4/83/86/a48386d024d02f316231bb5b8635798f.png" },
    { id: "midnight-luxury", name: "Midnight Luxury", color: "Midnight navy", price: 80, detail: "Dark navy blue waterproof wrapping with gold ribbon accents.", image: "https://i.pinimg.com/736x/75/91/1e/75911ef1eea4d5bae6547dfc00504a82.jpg" },
    { id: "minimalist-white", name: "Minimalist White", color: "Clean white", price: 45, detail: "Clean white tissue paper with pastel ribbon.", image: "https://i.pinimg.com/736x/23/e6/57/23e657e50be60d5c493b63c62614aa92.jpg" }
  ],
  occasions: [
    { id: "valentines", startMonth: 2, startDay: 11, endMonth: 2, endDay: 15, name: "Valentine's Day", message: "Flowers for someone special.", recommendedFlowerIds: [1, 2, 4] },
    { id: "christmas", startMonth: 12, startDay: 22, endMonth: 12, endDay: 26, name: "Christmas", message: "Bring a little seasonal color to someone’s home.", recommendedFlowerIds: [3, 5, 6] },
    { id: "newyear", startMonth: 12, startDay: 28, endMonth: 1, endDay: 1, name: "New Year's Day", message: "Start the year with something bright and beautiful.", recommendedFlowerIds: [1, 3, 6] },
    { id: "mothersday", startMonth: 5, startDay: 1, endMonth: 5, endDay: 14, name: "Mother's Day", message: "Celebrate someone who makes life bloom.", recommendedFlowerIds: [1, 4, 6] },
    { id: "halloween", startMonth: 10, startDay: 25, endMonth: 11, endDay: 2, name: "Halloween", message: "A little seasonal magic for Halloween.", recommendedFlowerIds: [8, 9, 10] }
  ],
  weatherPresets: [
    { id: "sunny", label: "Sunny", message: "Bright, cheerful blooms for a sunny day.", recommendedFlowerIds: [3, 2, 1] },
    { id: "rainy", label: "Rainy", message: "Bring some color indoors on a rainy day.", recommendedFlowerIds: [5, 6, 4] }
  ]
};
