# PetalHub — Revision Log (SIA Revisions)

Documentation of every change made for the revision round, so it can be used as the basis for the **Contribution to Revisions** score.

Files changed: `script.js` (customer + admin screens), `style.css` (new styles), `schema.sql` (one new column + unique key). New files: `api.php`, `config.php`, `.htaccess` (the XAMPP/PHP backend, see section 6) and `check-duplicates.sql`. `server.js`, `package.json` and `start.bat` (Node) were removed because the system now runs on XAMPP only.

**Database:** an existing `petalhub` database does **not** need to be re-imported. The first time the page is opened `api.php` adds the new `orders.checkout_key` column and its unique key automatically (a fresh import of the updated `schema.sql` also creates them).

---

## 1. Back buttons / navigation

**Problem:** Several screens were dead ends (login, register, checkout steps, admin). The browser Back button also left the site completely because the app never recorded its screens in history.

**Fix**

| Screen | Back / navigation added |
|---|---|
| Log in (also used by admin) | "Back to browsing" (or "Back to cart" if the cart has items). The text now says admins log in here too. |
| Register | "Back to log in" |
| "Have an account?" gate | "Back to cart" |
| Forgot password | "Back to log in" at the top and "Back to browsing" at the bottom |
| Pickup or delivery | "Back to cart" |
| Delivery address | "Change fulfillment" (already existed) |
| Payment | "Back to fulfillment" / "Back to delivery address" |
| Confirm order | "Back to payment" |
| Order confirmed | "Back to Browse" and "View My Orders" |
| My orders | "Back to browse" at the top, "Back to Browse" and "Go to cart" at the bottom |
| Admin panel | "View storefront" and "Log out" buttons in the header |

- The **browser Back / Forward buttons now work** between screens (History API, `go()` / `popstate` in `script.js`).
- `resolveScreen()` protects every screen: for example, a checkout page with an empty cart is redirected to the cart, and a logged-in user is not sent back to the login page.

## 2. Cart and checkout (duplicate orders)

**Root cause:** after an order was placed the cart (`state.cart`) was never emptied, so clicking Cart again showed the same items and "Proceed to checkout" created the same order again.

**Fix (combines your Options 1, 2 and 3)**
1. **Cart is emptied the moment the order is saved** (`confirmOrder`). The cart now only holds items that are *not yet ordered*; placed orders live only in **My Orders**. Active cart and completed orders are fully separate.
2. **Empty cart screen:** "Your cart is empty" with **Back to Browse** and **View My Orders**. No "Proceed to checkout" and no old order is shown.
3. **Cart with items:** buttons are **Back to Browse**, **View My Orders**, **Proceed to checkout** ("Continue shopping" was renamed). A note explains that placed orders are in My Orders.
4. **Stale pages cannot re-submit:** going back to Confirm/Payment after ordering redirects to the empty cart.
5. **Database-level duplicate guard (`api.php`):** each checkout sends a one-time `key`, saved in the new `orders.checkout_key` column with a `UNIQUE (user_id, checkout_key)` index. If the same checkout arrives again (double-click, slow network, retry, stale tab) the server returns the original order code and saves nothing. Because it is enforced by the database, it also holds across server restarts and simultaneous requests.
6. **Double-click protection:** the Confirm button is disabled and shows "Placing order…" while the request is running.

## 2b. Is the order saved twice in the database? (verification)

**Before the fix (original Node code, real MariaDB):** two identical checkouts created **two** rows in `orders` (`PH-130965` and `PH-957313`, both 3 Tulip, ₱36.00) and **deducted the stock twice** (40 → 34). So yes, the original code did store duplicates.

**After the fix (revised code, real MariaDB):**

| Test | Result |
|---|---|
| Same checkout sent twice | Same order code returned, 1 row |
| 8 simultaneous requests with the same key | Exactly 1 order row |
| A genuinely new order (new key) | New order created normally |
| Old client without a key | Still works |
| Real browser: double-click **Confirm order** | 1 row in `orders`, 1 in `order_items`, stock deducted once |
| Real browser: Back to Browse -> Cart -> browser Back x6 | Still 1 order; Confirm page is never reachable again |
| Second genuine order afterwards | 2 rows total, each with its own `checkout_key` |

**Existing duplicates from before the fix:** run `check-duplicates.sql` in phpMyAdmin. Query 1 lists suspected duplicate pairs; query 2 must return no rows (proof that new orders cannot repeat). The Admin > Orders screen now also shows a red **"Possible duplicate of PH-xxxxxx"** note on such orders. Clean them up with **Cancel order** (stock is returned automatically); do not delete rows by hand.

## 3. Delivery time

"Arrives within 1–2 days" was replaced with a realistic same-day estimate, defined once at the top of `script.js` (`PICKUP_ESTIMATE`, `DELIVERY_SHORT`, `DELIVERY_NOTE`):

- Delivery: **about 2–4 hours** within Caoayan and nearby Ilocos Sur towns; orders placed **after 5:00 PM go out the next morning**; farther areas may take longer.
- Pickup: ready in about 2 hours at the Ilocos Sur branch.
- Shown on the fulfillment choice, delivery address, confirm order and order-confirmed screens.

> The exact hours are our assumption. Edit the three constants if the real process is different.

## 4. Other bugs found and fixed while testing the whole system

| # | Issue found | Fix |
|---|---|---|
| a | Customers could add more stems than in stock (checkout then failed) | Quantity is capped to available stock on the product page and in the cart; "Out of stock" button when none are left |
| b | No way to remove an item from the cart | "Remove" link on every cart line |
| c | My Orders did not show the order status | Status badge (Pending / Preparing / Ready / Completed / Cancelled) plus delivery address |
| d | After login, customers with an empty cart were sent to an empty cart page | Now go to the browse page (cart page only if the cart has items) |
| e | Delivery form failed silently when fields were empty | Clear error message; typed values are kept |
| f | Forgot-password error showed the raw text `\u2019` | Fixed the escaped character |
| g | Admin account could add items to a cart and check out | Admin sees a note instead of "Add to cart" |
| h | Cart contents stayed after logging out (shared computers) | Cart and order data are cleared on logout |
| i | Expired session produced confusing errors | The user is sent to Log in with "Your session expired" |
| j | Prices used `$` although the shop uses GCash / Ilocos Sur | Changed to `₱` (one constant, `CURRENCY`) |
| k | Cart could keep more than the new stock after an admin edit | Cart is re-checked against stock whenever products reload |

## 5. Cart and checkout polish

| # | Improvement | Why |
|---|---|---|
| a | Guests can add flowers to the cart without logging in; they are asked to log in or register only when pressing **Proceed to checkout**, and then continue straight to the fulfillment step | Removes the login wall from browsing |
| b | The cart is kept if the page is refreshed (cleared when the order is placed or on logout) | Cart was lost on refresh |
| c | **Proceed to checkout** first re-checks stock; if items changed or sold out, a clear message is shown in the cart | Avoids failing at the last step |
| d | If placing the order fails, an inline message appears on the cart ("... Your order was not placed.") instead of a browser pop-up; the cart is kept | Clearer than `alert()` |
| e | Confirm screen now lists every item with its price, the total, and **Edit cart**; the page uses the Back buttons to go back a step (there are no separate Change links) | Easier to review and correct |
| f | Order-confirmed screen shows an order summary (items and total) with the estimated time | Customer sees what was ordered |
| g | **Bug fix:** on the Confirm screen the Payment, Account and estimated-time rows were missing when Delivery was chosen (introduced and fixed during these revisions) | Found while testing the delivery path |

## 6. Everything now runs on XAMPP (Apache + PHP + MySQL)

**Problem:** the system needed Node.js (`start.bat`, port 3000). Opening it the XAMPP way (`localhost/petalhub/`) showed "Something went wrong." because Apache had no backend to answer.

**Fix:** the backend was rewritten in PHP, so only XAMPP is needed.

| File | Purpose |
|---|---|
| `api.php` | All endpoints of the old server in PHP/PDO: products, register, login, logout, forgot/reset password, orders, my orders, admin orders, status changes, cancel (returns stock), admin products |
| `config.php` | MySQL user/password and the admin email/password |
| `.htaccess` | Routes `/petalhub/api/...` to `api.php`, passes the login header to PHP, blocks direct download of `config.php`, `schema.sql` and the documentation |
| `script.js` | Calls the API relative to its own folder. If the server has no URL rewriting it automatically uses `api.php?route=...` instead |

- Open **http://localhost/petalhub/** (folder inside `xampp\htdocs`). No installs, no `start.bat`.
- Same API, same database tables; the duplicate-order protection is identical (checked again in PHP).
- Passwords are stored with PBKDF2. Accounts that were made by the old Node version **still log in** (when PHP has the `sodium` extension, which current XAMPP includes) and are upgraded automatically on their first login.
- Clear messages if something is not running: "Cannot reach the PetalHub server..." (Apache/folder) and "Cannot connect to the MySQL database..." (MySQL/schema).
- Bug fixed while testing the move: an earlier edit of mine had removed two helper functions (`flowerById`, `stockQty`) from `script.js`, which broke the product page in the browser. They were restored, and a check confirmed every function from the original `script.js` still exists.

- Fixed a first-run problem found while testing: when the page is opened for the very first time several requests arrive at once and used to run the database setup at the same time, so some answered "Server error". The setup now runs once (a MySQL lock) and tolerates already-existing columns/keys. It was verified on the old `schema.sql` and on a half-migrated database, with 6 simultaneous requests.
- `config.php` has `PH_DEBUG`: when true (default) an error shows its real reason on screen to make problems easy to report; set it to `false` when everything works.

Tested on Apache 2.4 with mod_php and mod_rewrite (`AllowOverride All`, as in XAMPP) and MariaDB, in a real browser, including the case where `.htaccess` is ignored.

## How to test (checklist)

1. Copy the folder to `xampp\\htdocs`, start Apache and MySQL, import `schema.sql`, open http://localhost/petalhub/. Then: log in as customer → add a flower → Cart → Proceed to checkout → Pickup → Cash → Confirm. **Expected:** one new order in My Orders.
2. Click **Back to Browse**, then the **Cart** button. **Expected:** "Your cart is empty", no old items, no Proceed to checkout. The order appears only in **View My Orders**.
3. Use the browser Back button after ordering. **Expected:** you land on the empty cart, never on a re-submittable checkout.
4. Double-click **Confirm order**. **Expected:** only one order is created.
5. Add a new flower and order again. **Expected:** only the new item is in the cart; My Orders now has two orders.
6. Walk through log in, register, forgot password, fulfillment, delivery, payment, confirm, My Orders and Admin. **Expected:** every screen has a back/exit button.
7. Choose Delivery. **Expected:** the new 2–4 hour / next-morning estimate.
8. Log in as admin. **Expected:** "View storefront" and "Log out" are in the admin header; the admin cannot add to cart.

Automated checks run: 50 API checks on Apache + PHP + MariaDB (every endpoint, validation, duplicate-order and concurrency tests, admin actions, old-account compatibility, rate limit; all passed), 15 end-to-end checks in a real browser (register, cart, checkout with double-click, empty cart, browser Back, My Orders, admin Mark Preparing / Cancel; all passed, also with `.htaccess` disabled) and 13 UI-logic checks on the cart/checkout flow (all passed).
