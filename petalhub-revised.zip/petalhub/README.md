# PetalHub - Online Flower Ordering System
PHP + MySQL, runs entirely on **XAMPP** (Apache + MySQL + phpMyAdmin). No Node.js and no extra installs.

## One-time setup (about 3 minutes)
1. Open the **XAMPP Control Panel** and **Start Apache** and **Start MySQL** (both should turn green).
2. Copy this whole `petalhub` folder into `C:\xampp\htdocs\` so you get `C:\xampp\htdocs\petalhub\index.html`.
3. Open http://localhost/phpmyadmin > **Import** tab > choose `schema.sql` > **Go**.
   A `petalhub` database with 5 tables should appear on the left.
   (If you already have an older `petalhub` database you can import over it. The system adds the new columns by itself.)
4. Open **http://localhost/petalhub/** in Chrome. That is all.

## Accounts
- **Admin:** `admin@petalhub.com` / `petalhub2026` (created automatically the first time the page is opened).
  To use another email or password, edit `config.php` **before** the first run.
- **Customer:** click **Log in** > **Register a new account**.

## Settings (`config.php`)
XAMPP's MySQL normally has user `root` and **no password**, which is already the default. If you set a MySQL password,
put it in `DB_PASS`. The admin email and password are also in this file.

## Revisions
See **REVISIONS.md** for the list of changes (navigation, cart/checkout fix, duplicate-order protection, delivery time,
bug fixes, move to XAMPP/PHP) and a test checklist. Use `check-duplicates.sql` in phpMyAdmin to look for orders that were
duplicated by the old cart bug.

## Troubleshooting
| You see | What to do |
|---|---|
| "Cannot reach the PetalHub server..." | Apache is not running, or the folder is not at `xampp\htdocs\petalhub`. Open http://localhost/petalhub/ (not a file on your Desktop). |
| "Cannot connect to the MySQL database..." | Start MySQL in XAMPP, make sure `schema.sql` was imported, and check `DB_PASS` in `config.php`. |
| Page opens but products/login do nothing | Press **Ctrl+Shift+R** to reload without the old cached script. |
| "Server error. ..." followed by details | Take a screenshot of the whole message (it names the real cause) and send it to the developer. |
| "Too many attempts" | Too many logins in 5 minutes. Wait a few minutes. |
| Forgot the admin password | Change `ADMIN_PASSWORD` in `config.php`, then in phpMyAdmin run `DELETE FROM users WHERE role='admin';` and open the page again. |

Files: `index.html`, `style.css`, `script.js` (website) | `api.php` (backend) | `config.php` (settings) | `.htaccess` (URL routing and file protection) | `schema.sql` | `check-duplicates.sql`.
